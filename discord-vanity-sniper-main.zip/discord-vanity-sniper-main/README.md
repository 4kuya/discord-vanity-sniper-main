# Discord Vanity Sniper

**This bot allows you to spam the url without being caught by the ratelimit of the discord.**

*If anyone of you know how to make this code better you can open a pull request.*
